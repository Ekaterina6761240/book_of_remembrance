<?php
/*
Plugin Name: MMP Local Backup
Description: Локальные бэкапы БД и uploads в ZIP.
Version: 1.0.0
*/
if (!defined('ABSPATH')) exit;
class MMP_Local_Backup {
  static function init(){ add_action('admin_menu',[__CLASS__,'menu']); }
  static function menu(){ add_management_page('MMP Backup','MMP Backup','manage_options','mmp-backup',[__CLASS__,'render']); }
  static function render(){
    if(!current_user_can('manage_options')) wp_die('Нет прав');
    echo '<div class="wrap"><h1>MMP Local Backup</h1>';
    if(isset($_POST['mmp_backup']) && check_admin_referer('mmp_backup')){ $res=self::backup();
      if(is_wp_error($res)) echo '<div class="error"><p>'.esc_html($res->get_error_message()).'</p></div>'; else echo '<div class="updated"><p>Создан бэкап: '.esc_html($res).'</p></div>'; }
    echo '<form method="post">'; wp_nonce_field('mmp_backup'); submit_button('Создать бэкап сейчас','primary','mmp_backup'); echo '</form></div>';
  }
  static function backup(){
    if(!class_exists('ZipArchive')) return new WP_Error('nozip','ZipArchive недоступен');
    global $wpdb; $upload_dir = wp_get_upload_dir()['basedir']; $target_dir = WP_CONTENT_DIR . '/backups'; if(!file_exists($target_dir)) wp_mkdir_p($target_dir);
    $stamp = date('Ymd_His'); $sql_file = $target_dir . '/db_' . $stamp . '.sql';
    $tables=$wpdb->get_col('SHOW TABLES'); $sql="SET NAMES utf8mb4;\n";
    foreach($tables as $t){ $create=$wpdb->get_row("SHOW CREATE TABLE `$t`", ARRAY_N); $sql.="DROP TABLE IF EXISTS `$t`;\n".$create[1].";\n";
      $rows=$wpdb->get_results("SELECT * FROM `$t`", ARRAY_A);
      foreach($rows as $r){ $vals=array_map(function($v){ return isset($v)?("'".esc_sql($v)."'"):'NULL'; }, array_values($r));
        $sql .= "INSERT INTO `$t` VALUES (".implode(',', $vals).");\n"; } }
    file_put_contents($sql_file,$sql);
    $zip_file = $target_dir . '/backup_' . $stamp . '.zip'; $z=new ZipArchive(); if($z->open($zip_file, ZipArchive::CREATE)!==true) return new WP_Error('zip','Не удалось создать архив');
    $z->addFile($sql_file,'db.sql'); $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($upload_dir, FilesystemIterator::SKIP_DOTS));
    foreach($it as $f){ $z->addFile($f, 'uploads/'.substr($f, strlen($upload_dir)+1)); } $z->close(); unlink($sql_file); return $zip_file;
  }
}
MMP_Local_Backup::init();