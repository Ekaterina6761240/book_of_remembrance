<?php
/*
Plugin Name: MMP RU L10n
Description: Принудительные RU-настройки локали и форматов.
Version: 1.0.0
*/
if (!defined('ABSPATH')) exit;
add_action('init', function(){
  update_option('WPLANG','ru_RU');
  update_option('timezone_string','Europe/Moscow');
  update_option('date_format','d.m.Y');
  update_option('time_format','H:i');
});