<?php
/*
Plugin Name: MMP Metrica Proxy Helper
Description: Подключение Метрики через локальный прокси-скрипт.
Version: 1.0.0
*/
if (!defined('ABSPATH')) exit;
class MMP_Metrica_Proxy {
  const KEY='mmp_metrica_proxy';
  static function init(){ add_action('admin_menu',[__CLASS__,'menu']); add_action('admin_init',[__CLASS__,'settings']); add_action('wp_head',[__CLASS__,'inject'],1); }
  static function menu(){ add_options_page('Metrica Proxy','Metrica Proxy','manage_options','mmp-metrica-proxy',[__CLASS__,'render']); }
  static function settings(){ register_setting(self::KEY,self::KEY); add_settings_section('s','Параметры','__return_false','mmp-metrica-proxy');
    foreach(['counter_id','proxy_js_url'] as $k){ add_settings_field($k,$k,[__CLASS__,'field'],'mmp-metrica-proxy','s',['k'=>$k]); } }
  static function field($a){ $o=get_option(self::KEY,[]); $v=esc_attr($o[$a['k']]??''); echo '<input type="text" style="width:420px" name="'.self::KEY.'['.$a['k'].']" value="'.$v.'">'; }
  static function render(){ echo '<div class="wrap"><h1>Metrica Proxy</h1><form method="post" action="options.php">'; settings_fields(self::KEY); do_settings_sections('mmp-metrica-proxy'); submit_button(); echo '</form></div>'; }
  static function inject(){ $o=get_option(self::KEY,[]); if(empty($o['counter_id'])||empty($o['proxy_js_url'])) return;
    echo '<script>window.mmpMetrica={id:"'.esc_js($o['counter_id']).'"};</script><script src="'.esc_url($o['proxy_js_url']).'" defer></script>'; }
}
MMP_Metrica_Proxy::init();