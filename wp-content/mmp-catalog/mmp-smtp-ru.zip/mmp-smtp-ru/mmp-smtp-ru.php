<?php
/*
Plugin Name: MMP SMTP (RU)
Description: SMTP для провайдеров РФ (Yandex 360, Mail.ru и т.п.).
Version: 1.0.0
*/
if (!defined('ABSPATH')) exit;
class MMP_SMTP_RU {
  const KEY='mmp_smtp_ru';
  static function init(){ add_action('admin_menu',[__CLASS__,'menu']); add_action('admin_init',[__CLASS__,'settings']); add_action('phpmailer_init',[__CLASS__,'mailer']); }
  static function menu(){ add_options_page('SMTP (RU)','SMTP (RU)','manage_options','mmp-smtp-ru',[__CLASS__,'render']); }
  static function settings(){ register_setting(self::KEY,self::KEY); add_settings_section('s','Параметры SMTP','__return_false','mmp-smtp-ru');
    foreach(['host','port','secure','auth_user','auth_pass','from_email','from_name'] as $k){ add_settings_field($k,$k,[__CLASS__,'field'],'mmp-smtp-ru','s',['k'=>$k]); } }
  static function field($a){ $o=get_option(self::KEY,[]); $v=esc_attr($o[$a['k']]??''); echo '<input type="text" style="width:420px" name="'.self::KEY.'['.$a['k'].']" value="'.$v.'">'; }
  static function render(){ echo '<div class="wrap"><h1>SMTP (RU)</h1><form method="post" action="options.php">'; settings_fields(self::KEY); do_settings_sections('mmp-smtp-ru'); submit_button(); echo '</form>';
    echo '<p>Пример: smtp.yandex.ru:465 (ssl)</p></div>'; }
  static function mailer($phpmailer){ $o=get_option(self::KEY,[]); if(empty($o['host'])) return; $phpmailer->isSMTP(); $phpmailer->Host=$o['host']; $phpmailer->Port=intval($o['port']??465);
    $phpmailer->SMTPAuth=true; $phpmailer->Username=$o['auth_user']??''; $phpmailer->Password=$o['auth_pass']??''; $phpmailer->SMTPSecure=$o['secure']??'ssl';
    if(!empty($o['from_email'])){ $phpmailer->setFrom($o['from_email'],$o['from_name']??''); } }
}
MMP_SMTP_RU::init();